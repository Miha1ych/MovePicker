	const API = "https://api.themoviedb.org/3";
	const IMG = "https://image.tmdb.org/t/p/w500";
	const FALLBACK_IMG = "https://image.tmdb.org/t/p/w342";

	const $ = id => document.getElementById(id);

	let token = "";
	let controller = null;

	const cache = new Map();

	const CACHE_LIMIT = 300;

	function cacheSet(key, value) {
		cache.set(key, value);

		while (cache.size > CACHE_LIMIT) {

			/*
			 * Map хранит порядок вставки —
			 * удаляем самую старую запись.
			 */

			const oldestKey =
				cache.keys().next().value;

			cache.delete(oldestKey);
		}
	}
	
	function levenshtein(a, b) {

    a = String(a || "");
    b = String(b || "");

    if (a === b) {
        return 0;
    }

    if (!a.length) {
        return b.length;
    }

    if (!b.length) {
        return a.length;
    }

    const previous =
        Array.from(
            { length: b.length + 1 },
            (_, index) => index
        );

    for (
        let i = 1;
        i <= a.length;
        i++
    ) {

        const current =
            [i];

        for (
            let j = 1;
            j <= b.length;
            j++
        ) {

            const insert =
                current[j - 1] + 1;

            const remove =
                previous[j] + 1;

            const replace =
                previous[j - 1] +
                (
                    a[i - 1] ===
                    b[j - 1]
                        ? 0
                        : 1
                );

            current[j] =
                Math.min(
                    insert,
                    remove,
                    replace
                );
        }

        for (
            let j = 0;
            j < current.length;
            j++
        ) {
            previous[j] =
                current[j];
        }
    }

    return previous[b.length];
}

function normalizeSearchText(value) {

    return String(value || "")
        .toLowerCase()
        .replace(
            /ё/g,
            "е"
        )
        .replace(
            /[^\p{L}\p{N}]+/gu,
            " "
        )
        .replace(
            /\s+/g,
            " "
        )
        .trim();
}

function getFuzzyWordScore(
    queryWord,
    titleWord
) {

    if (
        !queryWord ||
        !titleWord
    ) {
        return 0;
    }

    if (
        queryWord ===
        titleWord
    ) {
        return 1;
    }

    if (
        titleWord.includes(
            queryWord
        ) ||
        queryWord.includes(
            titleWord
        )
    ) {
        return 0.85;
    }

    const distance =
        levenshtein(
            queryWord,
            titleWord
        );

    const maxLength =
        Math.max(
            queryWord.length,
            titleWord.length
        );

    if (!maxLength) {
        return 0;
    }

    const similarity =
        1 -
        distance /
        maxLength;

    /*
     * Для коротких слов
     * требуем более точное
     * совпадение.
     */

    if (
        maxLength <= 3 &&
        distance > 1
    ) {
        return 0;
    }

    if (
        maxLength <= 5 &&
        distance > 2
    ) {
        return 0;
    }

    if (
        maxLength <= 8 &&
        distance > 3
    ) {
        return 0;
    }

    if (
        similarity < 0.55
    ) {
        return 0;
    }

    return similarity;
}

	let likedMovies = {};
	let dislikedMovies = {};
	let favoriteMovies = {};

	let recommendationGeneration = 0;
	let liveRecommendationMovies = {};

	let adultKeywordIds = [];
	let trailerStyleInstalled = false;


	/* =========================
	   BASIC
	========================= */

	function status(text) {
		$("status").textContent = text;
	}

	function years() {
		const current = new Date().getFullYear();
		const select = $("year");

		for (let i = current; i >= 1900; i--) {
			const option = document.createElement("option");

			option.value = i;
			option.textContent = i;

			select.appendChild(option);
		}
	}


	/* =========================
	   STORAGE
	========================= */

	async function loadStorage() {
		return new Promise(resolve => {
			chrome.storage.local.get(
				[
					"liked_movies",
					"disliked_movies",
					"favorite_movies"
				],
				data => {

					likedMovies =
						data.liked_movies || {};

					dislikedMovies =
						data.disliked_movies || {};

					favoriteMovies =
						data.favorite_movies || {};

					resolve();
				}
			);
		});
	}

	function saveLikes() {
		chrome.storage.local.set({
			liked_movies: likedMovies
		});
	}

	function saveDislikes() {
		chrome.storage.local.set({
			disliked_movies: dislikedMovies
		});
	}

	function saveFavorites() {
		chrome.storage.local.set({
			favorite_movies: favoriteMovies
		});
	}

	function isLiked(id) {
		return Boolean(
			likedMovies[String(id)]
		);
	}

	function isDisliked(id) {
		return Boolean(
			dislikedMovies[String(id)]
		);
	}

	function isFavorite(id) {
		return Boolean(
			favoriteMovies[String(id)]
		);
	}


	/* =========================
	   ОБЛЕГЧЁННОЕ ХРАНЕНИЕ

	   В storage кладём не весь объект
	   от TMDB, а только реально
	   используемые поля.
	========================= */

	function pickMovieFields(movie) {
		return {
			id: movie.id,
			title: movie.title,
			original_title: movie.original_title,
			release_date: movie.release_date,
			poster_path: movie.poster_path,
			genre_ids: movie.genre_ids,
			vote_average: movie.vote_average,
			popularity: movie.popularity
		};
	}


	/* =========================
	   LIKE
	========================= */

	function toggleLike(movie, button) {
		const id = String(movie.id);

		if (likedMovies[id]) {

			delete likedMovies[id];

			button.classList.remove("liked");
			button.textContent = "♡";
			button.title = "Понравилось";

		} else {

			if (dislikedMovies[id]) {
				delete dislikedMovies[id];

				saveDislikes();

				const dislikeButton =
					document.querySelector(
						`.dislikeBtn[data-movie-id="${id}"]`
					);

				if (dislikeButton) {
					dislikeButton.classList.remove(
						"disliked"
					);

					dislikeButton.title =
						"Не моё";
				}
			}

			likedMovies[id] =
				pickMovieFields(movie);

const wasInPersonalRecommendations =
    document.querySelector(
        `#personalRecommendations .likeBtn[data-movie-id="${id}"]`
    );

if (wasInPersonalRecommendations) {
    liveRecommendationMovies[id] = movie;
}

button.classList.add("liked");
			button.textContent = "♥";
			button.title = "Убрать лайк";
			createLikeBurst(button);
		}

		saveLikes();

		recommendationGeneration++;

		loadPersonalRecommendations();
	}


	/* =========================
	   DISLIKE
	========================= */

	function toggleDislike(movie, button) {
		const id = String(movie.id);

		if (dislikedMovies[id]) {

			delete dislikedMovies[id];

			button.classList.remove("disliked");
			button.title = "Не моё";

		} else {

			if (likedMovies[id]) {
				delete likedMovies[id];

				saveLikes();

				const likeButton =
					document.querySelector(
						`.likeBtn[data-movie-id="${id}"]`
					);

				if (likeButton) {
					likeButton.classList.remove(
						"liked"
					);

					likeButton.textContent =
						"♡";

					likeButton.title =
						"Понравилось";
				}
			}

			dislikedMovies[id] =
				pickMovieFields(movie);

			button.classList.add("disliked");
			button.title = "Убрать из «Не моё»";
		}

		saveDislikes();

		recommendationGeneration++;

		loadPersonalRecommendations();
	}


	/* =========================
	   FAVORITES
	========================= */

	function toggleFavorite(movie, button) {
		const id = String(movie.id);

		if (favoriteMovies[id]) {
			delete favoriteMovies[id];

			button.classList.remove("favorited");
			button.textContent = "☆";
			button.title = "Добавить в избранное";

		} else {
    favoriteMovies[id] =
        pickMovieFields(movie);
    button.classList.add("favorited");
    button.textContent = "★";
    button.title = "Убрать из избранного";

    createFavoriteBurst(button);
}

		saveFavorites();

		updateFavoritesButton();
		renderFavorites();
	}


	/* =========================
	   FAVORITES UI
	========================= */

	function updateFavoritesButton() {
		const count =
			Object.keys(favoriteMovies).length;

		const button = $("favoritesBtn");

		button.textContent =
			count > 0 ? "★" : "☆";

		button.title =
			count > 0
				? `Избранное (${count})`
				: "Избранное";
	}

	function renderFavorites() {
		const grid =
			$("favoritesGrid");

		const empty =
			$("favoritesEmpty");

		grid.innerHTML = "";

		const movies =
			Object.values(
				favoriteMovies
			)
				.slice()
				.reverse();

		if (!movies.length) {
			empty.style.display =
				"block";

			return;
		}

		empty.style.display =
			"none";


		movies.forEach(movie => {

			const item =
				document.createElement("article");

			item.className =
				"favoriteCard";


			const posterWrap =
				document.createElement("div");

			posterWrap.className =
				"favoritePosterWrap";


			posterWrap.appendChild(
				createPoster(movie)
			);


			const likeButton =
				document.createElement("button");

			likeButton.className =
				"favoriteLikeBtn" +
				(
					isLiked(movie.id)
						? " liked"
						: ""
				);

			likeButton.dataset.movieId =
				String(movie.id);

			likeButton.textContent =
				isLiked(movie.id)
					? "♥"
					: "♡";

			likeButton.title =
				isLiked(movie.id)
					? "Убрать лайк"
					: "Понравилось";

			likeButton.onclick =
				event => {
					event.preventDefault();
					event.stopPropagation();

					toggleLike(
						movie,
						likeButton
					);
				};


			const trailerButton =
				document.createElement("button");

			trailerButton.className =
				"favoriteTrailerBtn";

			trailerButton.textContent =
				"▶";

			trailerButton.title =
				"Смотреть трейлер";

			trailerButton.onclick =
				event => {
					event.preventDefault();
					event.stopPropagation();

					openTrailer(
						movie,
						trailerButton
					);
				};


			const removeButton =
				document.createElement("button");

			removeButton.className =
				"favoriteRemoveBtn";

			removeButton.textContent =
				"×";

			removeButton.title =
				"Удалить из избранного";

			removeButton.onclick =
				event => {
					event.preventDefault();
					event.stopPropagation();

					const id =
						String(movie.id);

					delete favoriteMovies[id];

					saveFavorites();

					updateFavoritesButton();

					renderFavorites();
				};


			posterWrap.appendChild(
				likeButton
			);

			posterWrap.appendChild(
				trailerButton
			);

			posterWrap.appendChild(
				removeButton
			);


			item.appendChild(
				posterWrap
			);


			const title =
				document.createElement("div");

			title.className =
				"favoriteCardTitle";

			title.textContent =
				movie.title ||
				movie.original_title ||
				"Без названия";


			const meta =
				document.createElement("div");

			meta.className =
				"favoriteCardMeta";

			meta.textContent =
				(movie.release_date || "")
					.slice(0, 4) ||
				"—";


			item.appendChild(
				title
			);

			item.appendChild(
				meta
			);


			item.onclick = event => {

				if (event.target.closest("button")) {
					return;
				}

				const title =
					movie.title ||
					movie.original_title ||
					"Без названия";

				const searchUrl =
					"https://www.google.com/search?q=" +
					encodeURIComponent(
						title + " lord film"
					);

				window.open(
					searchUrl,
					"_blank"
				);
			};


			grid.appendChild(
				item
			);
		});
	}


	/* =========================
	   POSTERS
	========================= */

	function createPoster(movie) {
		if (!movie.poster_path) {
			const fallback =
				document.createElement("div");

			fallback.className =
				"poster posterFallback";

			fallback.textContent = "🎬";

			return fallback;
		}

		const img =
			document.createElement("img");

		img.className = "poster";

		img.loading = "lazy";
		img.decoding = "async";

		img.alt =
			movie.title ||
			movie.original_title ||
			"";

		const urls = [
			IMG + movie.poster_path,
			FALLBACK_IMG + movie.poster_path
		];

		let attempt = 0;

		img.src = urls[0];

		img.onerror = () => {
			attempt++;

			if (attempt < urls.length) {
				img.src = urls[attempt];
			} else {
				const fallback =
					document.createElement("div");

				fallback.className =
					"poster posterFallback";

				fallback.textContent = "🎬";

				img.replaceWith(fallback);
			}
		};

		return img;
	}


	/* =========================
	   MOVIE CARD
	========================= */

	function card(movie) {
		const title =
			movie.title ||
			movie.original_title ||
			"Без названия";

		const year =
    (movie.release_date || "")
        .slice(0, 4) || "—";

const genreNames = {
    28: "Боевик",
    12: "Приключения",
    16: "Мультфильм",
    35: "Комедия",
    80: "Криминал",
    99: "Документальный",
    18: "Драма",
    10751: "Семейный",
    14: "Фэнтези",
    36: "История",
    27: "Ужасы",
    10402: "Музыка",
    9648: "Детектив",
    10749: "Мелодрама",
    878: "Фантастика",
    10770: "Телевизионный фильм",
    53: "Триллер",
    10752: "Военный",
    37: "Вестерн"
};

const genres =
    Array.isArray(movie.genre_ids)
        ? movie.genre_ids
            .map(id => genreNames[Number(id)])
            .filter(Boolean)
            .slice(0, 3)
        : [];

const metaText =
    [year, ...genres].join(" · ");

const rating =
    Number(movie.vote_average || 0)
        .toFixed(1);

		const article =
			document.createElement("article");

		article.className = "card";


		const posterWrap =
			document.createElement("div");

		posterWrap.className =
			"posterWrap";

		posterWrap.appendChild(
			createPoster(movie)
		);


		const likeButton =
			document.createElement("button");

		likeButton.className =
			"likeBtn" +
			(isLiked(movie.id) ? " liked" : "");

		likeButton.dataset.movieId =
			String(movie.id);

		likeButton.textContent =
			isLiked(movie.id)
				? "♥"
				: "♡";

		likeButton.title =
			isLiked(movie.id)
				? "Убрать лайк"
				: "Понравилось";

		likeButton.onclick =
			event => {
				event.preventDefault();
				event.stopPropagation();

				toggleLike(
					movie,
					likeButton
				);
			};


		const dislikeButton =
			document.createElement("button");

		dislikeButton.className =
			"dislikeBtn" +
			(
				isDisliked(movie.id)
					? " disliked"
					: ""
			);

		dislikeButton.dataset.movieId =
			String(movie.id);

		dislikeButton.textContent =
			"👎";

		dislikeButton.title =
			isDisliked(movie.id)
				? "Убрать из «Не моё»"
				: "Не моё";

		dislikeButton.onclick =
			event => {
				event.preventDefault();
				event.stopPropagation();

				toggleDislike(
					movie,
					dislikeButton
				);
			};


		const favoriteButton =
			document.createElement("button");

		favoriteButton.className =
			"favoriteBtn" +
			(
				isFavorite(movie.id)
					? " favorited"
					: ""
			);

		favoriteButton.textContent =
			isFavorite(movie.id)
				? "★"
				: "☆";

		favoriteButton.title =
			isFavorite(movie.id)
				? "Убрать из избранного"
				: "Добавить в избранное";

		favoriteButton.onclick =
			event => {
				event.preventDefault();
				event.stopPropagation();

				toggleFavorite(
					movie,
					favoriteButton
				);
			};


		const trailerButton =
			document.createElement("button");

		trailerButton.className =
			"trailerBtn";

		trailerButton.textContent =
			"▶";

		trailerButton.title =
			"Смотреть трейлер";

		trailerButton.onclick =
			event => {
				event.preventDefault();
				event.stopPropagation();

				openTrailer(
					movie,
					trailerButton
				);
			};


		posterWrap.appendChild(
			likeButton
		);

		posterWrap.appendChild(
			dislikeButton
		);

		posterWrap.appendChild(
			favoriteButton
		);

		posterWrap.appendChild(
			trailerButton
		);

		article.appendChild(
			posterWrap
		);


		const titleElement =
			document.createElement("div");

		titleElement.className =
			"title";

		titleElement.textContent =
			title;

		titleElement.title =
			"Нажми, чтобы скопировать название";

		titleElement.addEventListener(
			"click",
			async event => {
				event.preventDefault();
				event.stopPropagation();

				try {
					await navigator.clipboard.writeText(
						title
					);

					const previous =
						titleElement.textContent;

					titleElement.textContent =
						"✓ Скопировано";

					setTimeout(() => {
						titleElement.textContent =
							previous;
					}, 900);

				} catch (error) {
					console.warn(
						"Clipboard:",
						error
					);
				}
			}
		);


		const meta =
			document.createElement("div");

		meta.className =
			"meta";

		meta.textContent =
    metaText;


const ratingElement =
    document.createElement("div");

		ratingElement.className =
			"rating";

		ratingElement.textContent =
			"★ " + rating + " · ";

		const ageElement =
			document.createElement("span");

		ageElement.className =
			"ageRating";

		ageElement.textContent =
			"…";

		ratingElement.appendChild(
			ageElement
		);

		getAgeRating(movie.id)
			.then(age => {
				ageElement.textContent =
					age;
			});

		article.appendChild(
			titleElement
		);

		article.appendChild(
			meta
		);

		article.appendChild(
			ratingElement
		);


		article.onclick = event => {

			if (event.target.closest("button")) {
				return;
			}

			if (event.target.closest(".title")) {
				return;
			}

			window.open(
				"https://www.google.com/search?q=" +
				encodeURIComponent(
					title + " lord film"
				),
				"_blank"
			);
		};

		return article;
	}


	/* =========================
	   HORIZONTAL SECTION
	========================= */

	function section(
		title,
		movies,
		id = "",
		loadMore = null
	) {
		if (!movies || !movies.length) {
			return null;
		}

		const sectionElement =
			document.createElement("section");

		sectionElement.className =
			"section";

		if (id) {
			sectionElement.id = id;
		}


		/*
		 * HEADER
		 */

		const head =
			document.createElement("div");

		head.className =
			"sectionHead";

		const h2 =
			document.createElement("h2");

		h2.textContent =
			title;

		const count =
			document.createElement("span");

		count.textContent =
			movies.length + " фильмов";

		/*
		 * Кнопка обновления
		 * для персональных рекомендаций.
		 */

 if (id === "personalRecommendations") {

    const refreshButton =
        document.createElement("button");

    refreshButton.type = "button";

    refreshButton.textContent = "↻";

    refreshButton.title =
        "Обновить рекомендации";

    refreshButton.style.cssText = `
        width: 30px;
        height: 30px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        margin-left: 8px;
        padding: 0;

        border: 1px solid rgba(255,255,255,.12);
        border-radius: 8px;

        background: rgba(255,255,255,.05);
        color: #aaa;

        font-size: 19px;
        line-height: 1;

        cursor: pointer;

        transition:
            background .15s ease,
            color .15s ease,
            transform .15s ease;
    `;

    refreshButton.onmouseenter = () => {
        refreshButton.style.background =
            "rgba(255,255,255,.1)";

        refreshButton.style.color =
            "#fff";

        refreshButton.style.transform =
            "rotate(30deg)";
    };

    refreshButton.onmouseleave = () => {
        refreshButton.style.background =
            "rgba(255,255,255,.05)";

        refreshButton.style.color =
            "#aaa";

        refreshButton.style.transform =
            "rotate(0deg)";
    };

    refreshButton.onclick =
        async event => {

            event.preventDefault();
            event.stopPropagation();

            if (refreshButton.disabled) {
                return;
            }

            refreshButton.disabled = true;

            refreshButton.textContent = "⟳";

            recommendationGeneration++;

            try {
                await loadPersonalRecommendations();
            } finally {
                refreshButton.disabled = false;
                refreshButton.textContent = "↻";
            }
        };


    /*
     * Кнопка стоит непосредственно
     * после заголовка «Для тебя».
     */

    h2.appendChild(
        refreshButton
    );

    head.appendChild(
        h2
    );

    head.appendChild(
        count
    );

} else {

    head.appendChild(
        h2
    );

    head.appendChild(
        count
    );
}


		/*
		 * SCROLLER
		 */

		const scroller =
			document.createElement("div");

		scroller.className =
			"movieScroller";


		/*
		 * LEFT ARROW
		 */

		const leftButton =
			document.createElement("button");

		leftButton.className =
			"scrollButton scrollLeft";

		leftButton.textContent =
			"‹";

		leftButton.title =
			"Прокрутить влево";


		/*
		 * RIGHT ARROW
		 */

		const rightButton =
			document.createElement("button");

		rightButton.className =
			"scrollButton scrollRight";

		rightButton.textContent =
			"›";

		rightButton.title =
			"Прокрутить вправо";


		/*
		 * GRID
		 */

		const grid =
			document.createElement("div");

		grid.className =
			"grid";


		/*
		 * MOVIES
		 */

		movies.forEach(movie => {
			grid.appendChild(
				card(movie)
			);
		});


		/*
		 * ARROWS
		 */

		leftButton.onclick = event => {
			event.preventDefault();
			event.stopPropagation();

			grid.scrollBy({
				left: -900,
				behavior: "smooth"
			});
		};

		rightButton.onclick = event => {
			event.preventDefault();
			event.stopPropagation();

			grid.scrollBy({
				left: 900,
				behavior: "smooth"
			});
		};


		/*
		 * EXPAND
		 */

		const expandButton =
			document.createElement("button");

		expandButton.className =
			"expandButton";

		expandButton.type =
			"button";

		expandButton.textContent =
			"Показать все ↓";

		expandButton.onclick = event => {

			event.preventDefault();
			event.stopPropagation();

			const expanded =
				grid.classList.toggle(
					"expanded"
				);

			if (expanded) {

				expandButton.textContent =
					"Свернуть ↑";

				grid.scrollLeft = 0;

				leftButton.style.display =
					"none";

				rightButton.style.display =
					"none";

			} else {

				expandButton.textContent =
					"Показать все ↓";

				grid.scrollLeft = 0;

				leftButton.style.display =
					"";

				rightButton.style.display =
					"";
			}
		};


		/*
		 * LOAD MORE
		 */

		let loadingMore = false;
		let hasMore = Boolean(loadMore);

		const loadMoreButton =
			document.createElement("button");

		loadMoreButton.className =
			"loadMoreButton";

		loadMoreButton.type =
			"button";

		loadMoreButton.textContent =
			"Показать ещё ↓";


		async function handleLoadMore() {

			if (
				!loadMore ||
				loadingMore ||
				!hasMore
			) {
				return;
			}

			loadingMore = true;

			loadMoreButton.disabled =
				true;

			loadMoreButton.textContent =
				"Загружаем…";


			try {

				const newMovies =
					await loadMore();


				/*
				 * Больше фильмов нет.
				 */

				if (
					!newMovies ||
					!newMovies.length
				) {

					hasMore = false;

					loadMoreButton.textContent =
						"Больше нет";

					loadMoreButton.disabled =
						true;

					loadingMore = false;

					return;
				}


				/*
				 * Добавляем новые фильмы
				 * перед кнопкой.
				 */

				newMovies.forEach(
					movie => {

						grid.insertBefore(
							card(movie),
							loadMoreButton
						);

					}
				);


				/*
				 * Обновляем количество.
				 *
				 * Кнопка не считается фильмом.
				 */

				const movieCount =
					[...grid.children]
						.filter(
							element =>
								element !==
								loadMoreButton
						)
						.length;

				count.textContent =
					movieCount +
					" фильмов";


				/*
				 * Возвращаем кнопку.
				 */

				loadMoreButton.textContent =
					"Показать ещё ↓";

				loadMoreButton.disabled =
					false;

				loadingMore = false;

			} catch (error) {

				console.error(
					"Load more:",
					error
				);

				if (
					error?.name ===
					"AbortError"
				) {
					loadingMore = false;
					return;
				}

				loadMoreButton.textContent =
					"Ошибка. Повторить";

				loadMoreButton.disabled =
					false;

				loadingMore = false;
			}
		}


		loadMoreButton.onclick =
			event => {

				event.preventDefault();
				event.stopPropagation();

				handleLoadMore();
			};


		/*
		 * BUILD
		 */

		scroller.appendChild(
			leftButton
		);

		scroller.appendChild(
			grid
		);

		scroller.appendChild(
			rightButton
		);


		/*
		 * Показать ещё —
		 * последняя карточка.
		 */

		if (loadMore) {

			grid.appendChild(
				loadMoreButton
			);
		}


		sectionElement.appendChild(
			head
		);

		sectionElement.appendChild(
			scroller
		);


		/*
		 * Показать все —
		 * отдельная кнопка под рядом.
		 */

		sectionElement.appendChild(
			expandButton
		);


		$("sections").appendChild(
			sectionElement
		);


		return sectionElement;
	}


	/* =========================
	   TRAILER UI
	========================= */

	function installEnhancementStyles() {
		if (trailerStyleInstalled) {
			return;
		}

		trailerStyleInstalled = true;

		const style =
			document.createElement("style");

		style.textContent = `
			.movieScroller {
				position: relative;
				width: 100%;
				min-width: 0;
			}

			.movieScroller .grid {
				display: grid;
				grid-auto-flow: column;
				grid-template-rows: 1fr;
				grid-auto-columns: 180px;
				grid-template-columns: none;

				overflow-x: auto;
				overflow-y: hidden;

				scrollbar-width: none;

				scroll-behavior: smooth;

				padding:
					4px 42px 14px 42px;
			}

			.movieScroller .grid::-webkit-scrollbar {
				display: none;
			}

			.movieScroller .grid.expanded {
				display: grid;

				grid-auto-flow: row;
				grid-template-columns:
					repeat(auto-fill, minmax(180px, 1fr));

				grid-auto-columns: unset;

				overflow-x: hidden;
				overflow-y: visible;

				padding:
					4px 0 14px 0;
			}

			.scrollButton {
				position: absolute;

				top: 42%;
				transform: translateY(-50%);

				z-index: 20;

				width: 38px;
				height: 72px;

				border: 0;
				border-radius: 12px;

				background:
					rgba(20, 20, 24, .92);

				color: white;

				font-size: 38px;
				line-height: 1;

				cursor: pointer;

				display: flex;
				align-items: center;
				justify-content: center;

				transition:
					background .15s ease,
					transform .15s ease;
			}

			.scrollButton:hover {
				background:
					rgba(45, 45, 52, .98);

				transform:
					translateY(-50%) scale(1.05);
			}

			.scrollLeft {
				left: 0;
			}

			.scrollRight {
				right: 0;
			}

			.expandButton {
				display: block;

				margin: 2px auto 0;

				padding: 9px 18px;

				border: 1px solid
					rgba(255,255,255,.10);

				border-radius: 10px;

				background:
					rgba(255,255,255,.04);

				color: #ddd;

				cursor: pointer;

				transition:
					background .15s ease,
					color .15s ease;
			}

			.expandButton:hover {
				background:
					rgba(255,255,255,.08);

				color: white;
			}

			.dislikeBtn {
				position: absolute;

				left: 10px;
				bottom: 10px;

				width: 34px;
				height: 34px;

				border: 0;
				border-radius: 50%;

				background:
					rgba(0, 0, 0, .78);

				color: white;

				font-size: 15px;

				cursor: pointer;

				display: flex;
				align-items: center;
				justify-content: center;

				opacity: 0;

				transition:
					opacity .15s ease,
					transform .15s ease,
					background .15s ease;
			}

			.posterWrap:hover .dislikeBtn {
				opacity: 1;
			}

			.dislikeBtn:hover {
				background:
					rgba(255,255,255,.18);

				transform: scale(1.08);
			}

			.dislikeBtn.disliked {
				opacity: 1;

				background:
					rgba(220, 55, 55, .9);
			}

			.dislikeBtn:active {
				transform: scale(.94);
			}

			.trailerBtn {
				position: absolute;

				right: 10px;
				bottom: 10px;

				width: 34px;
				height: 34px;

				border: 0;
				border-radius: 50%;

				background:
					rgba(0,0,0,.78);

				color: white;

				font-size: 14px;

				cursor: pointer;

				display: flex;
				align-items: center;
				justify-content: center;

				opacity: 0;

				transition:
					opacity .15s ease,
					transform .15s ease,
					background .15s ease;
			}

			.posterWrap:hover .trailerBtn {
				opacity: 1;
			}

			.trailerBtn:hover {
				background:
					rgba(255,255,255,.18);

				transform: scale(1.08);
			}

			.trailerModal {
				position: fixed;

				inset: 0;

				z-index: 99999;

				display: flex;

				align-items: center;
				justify-content: center;

				padding: 30px;

				background:
					rgba(0,0,0,.82);

				backdrop-filter:
					blur(8px);
			}

			.trailerModal.hidden {
				display: none;
			}

			.trailerBox {
				position: relative;

				width: min(1100px, 94vw);

				background:
					#111;

				border:
					1px solid
					rgba(255,255,255,.10);

				border-radius: 16px;

				overflow: hidden;

				box-shadow:
					0 30px 100px
					rgba(0,0,0,.6);
			}

			.trailerVideo {
				display: block;

				width: 100%;

				aspect-ratio: 16 / 9;

				border: 0;

				background: #000;
			}

			.trailerClose {
				position: absolute;

				right: 12px;
				top: 12px;

				z-index: 5;

				width: 38px;
				height: 38px;

				border: 0;
				border-radius: 50%;

				background:
					rgba(0,0,0,.75);

				color: white;

				font-size: 25px;

				cursor: pointer;
			}

			.trailerTitle {
				padding: 14px 18px;

				font-size: 17px;
				font-weight: 700;

				color: white;
			}

			.favoriteCard {
				position: relative;
			}

			.favoritePosterWrap {
				position: relative;
				width: 100%;
			}

			.favoritePosterWrap .poster {
				display: block;
				width: 100%;
				height: auto;
			}

			.favoriteLikeBtn {
				position: absolute;

				left: 10px;
				bottom: 10px;

				width: 34px;
				height: 34px;

				padding: 0;

				border: 0 !important;
				border-radius: 50%;

				background:
					rgba(20, 20, 24, .95) !important;

				color: #aaa !important;

				font-size: 20px;
				line-height: 1;

				cursor: pointer;

				display: flex;
				align-items: center;
				justify-content: center;

				opacity: 0;

				z-index: 10;

				box-shadow:
					0 2px 8px rgba(0,0,0,.65);

				text-shadow:
					0 1px 3px rgba(0,0,0,.9);

				transition:
					opacity .15s ease,
					background .15s ease,
					color .15s ease,
					transform .15s ease;
			}

			.favoritePosterWrap:hover
			.favoriteLikeBtn {
				opacity: 1;
			}

			.favoriteLikeBtn:hover {
				background:
					rgba(45, 45, 52, .98) !important;

				color: white !important;

				transform:
					scale(1.08);
			}

			.favoriteLikeBtn.liked {
				opacity: 1;

				background:
					rgba(20, 20, 24, .95) !important;

				color:
					#ff5c70 !important;
			}

			.favoriteLikeBtn.liked:hover {
				background:
					rgba(45, 45, 52, .98) !important;

				color:
					#ff7182 !important;
			}

			.favoriteLikeBtn:active {
				transform:
					scale(.94);
			}

			.favoriteTrailerBtn {
				position: absolute;

				right: 10px;
				bottom: 10px;

				width: 34px;
				height: 34px;

				padding: 0;

				border: 0 !important;
				border-radius: 50%;

				background:
					rgba(20, 20, 24, .95) !important;

				color: #aaa !important;

				font-size: 14px;
				line-height: 1;

				cursor: pointer;

				display: flex;
				align-items: center;
				justify-content: center;

				opacity: 0;

				z-index: 10;

				box-shadow:
					0 2px 8px rgba(0,0,0,.65);

				text-shadow:
					0 1px 3px rgba(0,0,0,.9);

				transition:
					opacity .15s ease,
					background .15s ease,
					color .15s ease,
					transform .15s ease;
			}

			.favoritePosterWrap:hover
			.favoriteTrailerBtn {
				opacity: 1;
			}

			.favoriteTrailerBtn:hover {
				background:
					rgba(45, 45, 52, .98) !important;

				color:
					white !important;

				transform:
					scale(1.08);
			}

			.favoriteTrailerBtn:active {
				transform:
					scale(.94);
			}

			.favoriteRemoveBtn {
				position: absolute;

				top: 8px;
				right: 8px;

				width: 30px;
				height: 30px;

				padding: 0;

				border: 0 !important;
				border-radius: 50%;

				background:
					rgba(20, 20, 24, .95) !important;

				color: #aaa !important;

				font-size: 21px;
				font-weight: 500;

				line-height: 1;

				display: flex;
				align-items: center;
				justify-content: center;

				cursor: pointer;

				z-index: 20;

				opacity: 1;

				box-shadow:
					0 2px 8px rgba(0,0,0,.65);

				text-shadow:
					0 1px 3px rgba(0,0,0,.9);

				transition:
					background .15s ease,
					color .15s ease,
					transform .15s ease;
			}

			.favoriteRemoveBtn:hover {
				background:
					rgba(45, 45, 52, .98) !important;

				color:
					white !important;

				transform:
					scale(1.08);
			}

			.favoriteRemoveBtn:active {
				transform:
					scale(.94);
			}
		`;

		document.head.appendChild(style);
	}


	function ensureTrailerModal() {
		let modal =
			document.getElementById(
				"trailerModal"
			);

		if (modal) {
			return modal;
		}

		modal =
			document.createElement("div");

		modal.id =
			"trailerModal";

		modal.className =
			"trailerModal hidden";

		modal.innerHTML = `
			<div class="trailerBox">
				<button
					class="trailerClose"
					id="trailerClose"
					type="button"
				>×</button>

				<iframe
					class="trailerVideo"
					id="trailerVideo"
					allow="autoplay; encrypted-media; picture-in-picture"
					allowfullscreen
				></iframe>

				<div
					class="trailerTitle"
					id="trailerTitle"
				></div>
			</div>
		`;

		document.body.appendChild(modal);

		modal.addEventListener(
			"click",
			event => {
				if (event.target === modal) {
					closeTrailer();
				}
			}
		);

		document
			.getElementById("trailerClose")
			.onclick = closeTrailer;

		return modal;
	}

	function closeTrailer() {
		const modal =
			document.getElementById(
				"trailerModal"
			);

		const video =
			document.getElementById(
				"trailerVideo"
			);

		if (!modal) {
			return;
		}

		modal.classList.add("hidden");

		if (video) {
			video.src = "";
		}
	}

	function escapeHtml(value) {
		return String(value || "")
			.replaceAll("&", "&amp;")
			.replaceAll("<", "&lt;")
			.replaceAll(">", "&gt;")
			.replaceAll('"', "&quot;")
			.replaceAll("'", "&#039;");
	}

	function pickTrailer(videos) {
		if (!videos || !videos.length) {
			return null;
		}

		const youtube =
			videos.filter(
				video =>
					video.site === "YouTube" &&
					video.key
			);

		if (!youtube.length) {
			return null;
		}

		const trailer =
			youtube.find(
				video =>
					video.type === "Trailer"
			);

		if (trailer) {
			return trailer;
		}

		const officialTrailer =
			youtube.find(
				video =>
					video.official === true &&
					video.type === "Trailer"
			);

		if (officialTrailer) {
			return officialTrailer;
		}

		const teaser =
			youtube.find(
				video =>
					video.type === "Teaser"
			);

		if (teaser) {
			return teaser;
		}

		const clip =
			youtube.find(
				video =>
					video.type === "Clip"
			);

		return clip || youtube[0];
	}

	async function openTrailer(movie, button) {
		const modal =
			ensureTrailerModal();

		const video =
			document.getElementById(
				"trailerVideo"
			);

		const title =
			document.getElementById(
				"trailerTitle"
			);

		button.disabled = true;

		title.textContent =
			"Загрузка трейлера…";

		video.src = "";

		modal.classList.remove("hidden");

		try {
			let data;

			try {
				data = await api(
					`/movie/${movie.id}/videos`,
					{
						language: "ru-RU"
					}
				);
			} catch {
				data = null;
			}

			let trailer =
				pickTrailer(
					data?.results || []
				);

			if (!trailer) {
				data = await api(
					`/movie/${movie.id}/videos`,
					{
						language: "en-US"
					}
				);

				trailer =
					pickTrailer(
						data?.results || []
					);
			}

			if (!trailer) {
				title.textContent =
					"Трейлер для этого фильма не найден.";

				return;
			}

			const videoUrl =
				"https://www.youtube.com/embed/" +
				encodeURIComponent(trailer.key) +
				"?autoplay=1&rel=0";

			video.src = videoUrl;

			title.textContent =
				movie.title ||
				movie.original_title ||
				"Трейлер";

		} catch (error) {
			console.error(
				"Trailer error:",
				error
			);

			title.textContent =
				"Не удалось загрузить трейлер.";

		} finally {
			button.disabled = false;
		}
	}

	document.addEventListener(
		"keydown",
		event => {
			if (event.key === "Escape") {
				closeTrailer();
			}
		}
	);


	/* =========================
	   API
	========================= */

	function cacheKey(path, params) {
		return (
			path +
			"?" +
			new URLSearchParams(params)
				.toString()
		);
	}

	async function api(
		path,
		params = {},
		signal = undefined
	) {
		if (!token) {
			throw Error("NO_TOKEN");
		}

		const key =
			cacheKey(path, params);

		if (cache.has(key)) {
			return cache.get(key);
		}

		const url =
			new URL(API + path);

		Object.entries(params)
			.forEach(([key, value]) => {
				if (
					value !== "" &&
					value != null
				) {
					url.searchParams.set(
						key,
						value
					);
				}
			});

		const response =
			await fetch(url, {
				signal,

				headers: {
					Authorization:
						"Bearer " + token,

					accept:
						"application/json"
				}
			});

		if (!response.ok) {
			throw Error(
				"TMDB " +
				response.status
			);
		}

		const data =
			await response.json();

		cacheSet(
			key,
			data
		);

		return data;
	}


	/* =========================
	   ADULT / 18+
	========================= */

	const KNOWN_ADULT_KEYWORDS = [
		11190,
		3182,
		246601
	];

	const ADULT_KEYWORD_NAMES = [
		"eroticism",
		"sexuality",
		"sexual attraction",
		"seduction",
		"nudity",
		"nude",
		"erotic thriller",
		"sex scene",
		"sexual fantasy"
	];

	async function getAdultKeywordIds() {

		if (adultKeywordIds.length) {
			return adultKeywordIds;
		}

		const ids = [
			...KNOWN_ADULT_KEYWORDS
		];

		const results =
			await Promise.all(
				ADULT_KEYWORD_NAMES.map(
					async name => {

						try {

							const data =
								await api(
									"/search/keyword",
									{
										query: name,
										language: "en-US"
									}
								);

							const exact =
								(data.results || [])
									.find(
										keyword =>
											String(
												keyword.name
											).toLowerCase() ===
											name.toLowerCase()
									);

							return exact
								? Number(exact.id)
								: null;

						} catch {
							return null;
						}
					}
				)
			);

		results.forEach(id => {

			if (id) {
				ids.push(id);
			}

		});

		adultKeywordIds =
			[...new Set(ids)];

		return adultKeywordIds;
	}

	function ensureAdultGenreOption() {

		const select =
			$("genre");

		if (!select) {
			return;
		}

		if (
			select.querySelector(
				'option[value="adult"]'
			)
		) {
			return;
		}

		const option =
			document.createElement("option");

		option.value = "adult";
		option.textContent = "🔞 18+";

		select.appendChild(option);
	}


	/* =========================
	   FILTERS
	========================= */

	function commonParams() {
		return {
			language: "ru-RU",
			region: "RU",

			include_adult: "false",

			"vote_count.gte": "50"
		};
	}

	function filterParams() {
		const genre =
			$("genre").value;

		const rating =
			$("rating").value;

		const age =
			$("age").value;

		const year =
			$("year").value;

		const sort =
			$("sort").value;

		const params = {
			...commonParams(),

			sort_by:
				sort ||
				"popularity.desc"
		};

		if (genre === "adult") {
			params.include_adult = "true";
		} else if (genre) {
			params.with_genres =
				genre;
		}

		if (rating) {
			params["vote_average.gte"] =
				rating;
		}

		if (year) {
			params.primary_release_year =
				year;
		}

		if (age === "0") {
			params.certification_country =
				"US";

			params["certification.lte"] =
				"G";

		} else if (age === "6") {
			params.certification_country =
				"US";

			params["certification.lte"] =
				"PG";

		} else if (age === "12") {
			params.certification_country =
				"US";

			params["certification.lte"] =
				"PG-13";

		} else if (age === "16") {
			params.certification_country =
				"US";

			params["certification.gte"] =
				"R";

		} else if (age === "18") {
			params.include_adult =
				"true";

			params.certification_country =
				"US";

			params["certification.gte"] =
				"NC-17";
		}

		return params;
	}

	async function buildDiscoverParams() {
		const params =
			filterParams();

		if (
			$("genre").value ===
			"adult"
		) {
			const ids =
				await getAdultKeywordIds();

			if (ids.length) {
				params.with_keywords =
					ids.join("|");
			}
		}

		return params;
	}


	/* =========================
	   MOVIE HELPERS
	========================= */

	const certificationCache = new Map();

	async function getAgeRating(movieId) {
		const id = String(movieId);

		if (certificationCache.has(id)) {
			return certificationCache.get(id);
		}

		try {
			const data = await api(
				`/movie/${movieId}/release_dates`,
				{}
			);

			const results =
				data.results || [];

			const ru =
				results.find(
					country =>
						country.iso_3166_1 === "RU"
				);

			if (ru) {
				const certification =
					(ru.release_dates || [])
						.map(item =>
							item.certification
						)
						.find(Boolean);

				if (certification) {
					const rating =
						normalizeAgeRating(
							certification
						);

					certificationCache.set(
						id,
						rating
					);

					return rating;
				}
			}

			const us =
				results.find(
					country =>
						country.iso_3166_1 === "US"
				);

			if (us) {
				const certification =
					(us.release_dates || [])
						.map(item =>
							item.certification
						)
						.find(Boolean);

				if (certification) {
					const rating =
						normalizeAgeRating(
							certification
						);

					certificationCache.set(
						id,
						rating
					);

					return rating;
				}
			}

		} catch (error) {
			console.warn(
				"Age rating:",
				movieId,
				error
			);
		}

		certificationCache.set(
			id,
			"—"
		);

		return "—";
	}


	function normalizeAgeRating(certification) {
		const value =
			String(certification)
				.trim()
				.toUpperCase();

		if (
			value === "0+" ||
			value === "0"
		) {
			return "0+";
		}

		if (
			value === "6+" ||
			value === "6"
		) {
			return "6+";
		}

		if (
			value === "12+" ||
			value === "12"
		) {
			return "12+";
		}

		if (
			value === "16+" ||
			value === "16"
		) {
			return "16+";
		}

		if (
			value === "18+" ||
			value === "18"
		) {
			return "18+";
		}

		if (value === "G") {
			return "0+";
		}

		if (value === "PG") {
			return "6+";
		}

		if (value === "PG-13") {
			return "12+";
		}

		if (value === "R") {
			return "16+";
		}

		if (value === "NC-17") {
			return "18+";
		}

		if (
			/^\d+\+$/.test(value)
		) {
			return value;
		}

		return "—";
	}

	function dedupeMovies(movies) {
		const map = new Map();

		for (const movie of movies) {
			if (
				movie &&
				movie.id &&
				!map.has(movie.id)
			) {
				map.set(
					movie.id,
					movie
				);
			}
		}

		return [...map.values()];
	}

	function filterExcludedMovies(
		movies
	) {
		return movies.filter(
			movie =>
				!isLiked(movie.id) &&
				!isDisliked(movie.id) &&
				!isFavorite(movie.id)
		);
	}

	function shuffleArray(items) {
		const result = items.slice();

		for (
			let i = result.length - 1;
			i > 0;
			i--
		) {
			const j =
				Math.floor(
					Math.random() * (i + 1)
				);

			[result[i], result[j]] =
				[result[j], result[i]];
		}

		return result;
	}

	function randomizeMovies(movies) {
		return shuffleArray(movies);
	}


	/* =========================
	   DISCOVER MULTIPLE PAGES
	========================= */

	async function fetchDiscoverPages(
		params,
		pages = 3,
		signal,
		startPage = 1
	) {
		const requests = [];

		for (
			let page = startPage;
			page < startPage + pages;
			page++
		) {
			requests.push(
				api(
					"/discover/movie",
					{
						...params,
						page
					},
					signal
				)
			);
		}

		const results =
			await Promise.all(
				requests
			);

		const movies =
			results.flatMap(
				result =>
					result.results || []
			);

		return dedupeMovies(
			movies
		);
	}


	/* =========================
	   PERSONAL RECOMMENDATIONS
	========================= */

	function buildTasteProfile(likedMovies) {
		const genreWeights = new Map();

		const movies =
			likedMovies
				.slice()
				.reverse();

		movies.forEach((movie, index) => {

			const weight =
				Math.max(
					1,
					1.5 - index * 0.08
				);

			const genres =
				Array.isArray(
					movie.genre_ids
				)
					? movie.genre_ids
					: [];

			genres.forEach(genreId => {

				const current =
					genreWeights.get(
						Number(genreId)
					) || 0;

				genreWeights.set(
					Number(genreId),
					current + weight
				);
			});
		});

		return {
			genreWeights
		};
	}


	function getGenreMatchScore(
		movie,
		tasteProfile
	) {
		const genres =
			Array.isArray(
				movie.genre_ids
			)
				? movie.genre_ids
				: [];

		if (!genres.length) {
			return 0;
		}

		let score = 0;

		genres.forEach(genreId => {

			score +=
				tasteProfile.genreWeights.get(
					Number(genreId)
				) || 0;
		});

		return (
			score /
			Math.sqrt(genres.length)
		);
	}


	function scoreRecommendation(
		movie,
		recommendationCount,
		tasteProfile
	) {
		const rating =
			Number(
				movie.vote_average || 0
			);

		const popularity =
			Number(
				movie.popularity || 0
			);

		const genreMatch =
			getGenreMatchScore(
				movie,
				tasteProfile
			);

		const similarityScore =
			recommendationCount * 90;

		const genreScore =
			genreMatch * 32;

		const ratingScore =
			Math.max(
				0,
				rating - 5
			) * 7;

		const popularityScore =
			Math.log10(
				Math.max(
					1,
					popularity
				)
			) * 4;

		let freshnessScore = 0;

		if (movie.release_date) {

			const release =
				new Date(
					movie.release_date
				);

			if (!Number.isNaN(
				release.getTime()
			)) {

				const ageYears =
					(
						Date.now() -
						release.getTime()
					) /
					(
						1000 *
						60 *
						60 *
						24 *
						365
					);

				freshnessScore =
					Math.max(
						0,
						8 -
						Math.max(
							0,
							ageYears
						) * 0.7
					);
			}
		}

		let dislikePenalty = 0;

		const disliked =
			Object.values(
				dislikedMovies
			);

		const movieGenres =
			Array.isArray(
				movie.genre_ids
			)
				? movie.genre_ids.map(Number)
				: [];

		disliked.forEach(
			dislikedMovie => {

				const dislikedGenres =
					Array.isArray(
						dislikedMovie.genre_ids
					)
						? dislikedMovie.genre_ids.map(
							Number
						)
						: [];

				const commonGenres =
					movieGenres.filter(
						genreId =>
							dislikedGenres.includes(
								genreId
							)
					).length;

				if (commonGenres > 0) {
					dislikePenalty +=
						commonGenres * 12;
				}
			}
		);

		const randomScore =
			Math.random() * 12;

		return (
			similarityScore +
			genreScore +
			ratingScore +
			popularityScore +
			freshnessScore +
			randomScore -
			dislikePenalty
		);
	}


async function collectRecommendations(
    signal,
    page = 1
) {
    const liked =
        Object.values(
            likedMovies
        );

    if (!liked.length) {
        return [];
    }

    const tasteProfile =
        buildTasteProfile(
            liked
        );

    const sources =
        liked
            .slice()
            .reverse()
            .slice(0, 10);

    const recommendationMap =
        new Map();

    const requests =
        sources.map(
            movie =>
                api(
                    `/movie/${movie.id}/recommendations`,
                    {
                        language:
                            "ru-RU",

                        page
                    },
                    signal
                ).catch(
                    () => ({
                        results: []
                    })
                )
        );

    const responses =
        await Promise.all(
            requests
        );

    responses.forEach(
        (response, sourceIndex) => {

            const source =
                sources[sourceIndex];

            (
                response.results ||
                []
            ).forEach(movie => {

                if (
                    !movie ||
                    !movie.id
                ) {
                    return;
                }

                if (
                    isLiked(movie.id) ||
                    isDisliked(movie.id) ||
                    isFavorite(movie.id)
                ) {
                    return;
                }

                let item =
                    recommendationMap.get(
                        movie.id
                    );

                if (!item) {

                    item = {
                        movie,
                        count: 0,
                        sources: new Set()
                    };

                    recommendationMap.set(
                        movie.id,
                        item
                    );
                }

                if (
                    !item.sources.has(
                        source.id
                    )
                ) {

                    item.sources.add(
                        source.id
                    );

                    item.count++;
                }
            });
        }
    );

    const scored =
        [...recommendationMap.values()]
            .map(item => {

                const score =
                    scoreRecommendation(
                        item.movie,
                        item.count,
                        tasteProfile
                    );

                return {
                    movie:
                        item.movie,

                    score
                };
            });

    scored.sort(
        (a, b) =>
            b.score - a.score
    );

    const top =
        scored.slice(
            0,
            30
        );

    const result = [];

    for (
        let i = 0;
        i < top.length;
        i += 5
    ) {

        const block =
            shuffleArray(
                top.slice(
                    i,
                    i + 5
                )
            );

        result.push(
            ...block
        );
    }

    return result
        .map(
            item =>
                item.movie
        )
        .slice(
            0,
            30
        );
}
async function loadPersonalRecommendations() {
    const generation =
        recommendationGeneration;

    const likedCount =
        Object.keys(
            likedMovies
        ).length;

    const oldSection =
        document.getElementById(
            "personalRecommendations"
        );

    /*
     * Запоминаем, был ли список развёрнут.
     */

        const wasExpanded =
        oldSection?.querySelector(
            ".movieScroller .grid"
        )?.classList.contains(
            "expanded"
        ) ?? false;

    if (oldSection) {
        oldSection.remove();
    }

    if (likedCount < 3) {
        return;
    }

    try {

        /*
         * Первая страница рекомендаций.
         */

        let recommendationPage = 1;

        const movies =
            await collectRecommendations(
                undefined,
                recommendationPage
            );

        if (
            generation !==
            recommendationGeneration
        ) {
            return;
        }

        const filtered =
    filterExcludedMovies(
        movies
    );

for (const id in liveRecommendationMovies) {
    const movie =
        liveRecommendationMovies[id];

    if (
        !filtered.some(
            item =>
                String(item.id) ===
                String(movie.id)
        )
    ) {
        filtered.unshift(movie);
    }
}

if (!filtered.length) {
            return;
        }


        /*
         * Запоминаем уже показанные фильмы,
         * чтобы следующие страницы
         * не создавали дубликаты.
         */

        const displayedIds =
            new Set(
                filtered.map(
                    movie =>
                        movie.id
                )
            );


        /*
         * Создаём секцию.
         */

        const element =
            section(
                "🎯 Для тебя",
                filtered,
                "personalRecommendations",
                async () => {

                    /*
                     * Пробуем следующие страницы,
                     * пока не найдём новые фильмы.
                     */

                    for (
                        let attempt = 0;
                        attempt < 5;
                        attempt++
                    ) {

                        recommendationPage++;

                        const newMovies =
                            await collectRecommendations(
                                undefined,
                                recommendationPage
                            );

                        const uniqueMovies =
                            filterExcludedMovies(
                                newMovies
                            ).filter(
                                movie => {

                                    if (
                                        displayedIds.has(
                                            movie.id
                                        )
                                    ) {
                                        return false;
                                    }

                                    displayedIds.add(
                                        movie.id
                                    );

                                    return true;
                                }
                            );

                        if (
                            uniqueMovies.length
                        ) {
                            return uniqueMovies;
                        }
                    }

                    return [];
                }
            );
        /*
         * Возвращаем прежнее состояние
         * развёрнутого списка.
         */

 if (wasExpanded && element) {

    const grid =
        element.querySelector(
            ".movieScroller .grid"
        );

    const expandButton =
        element.querySelector(
            ".expandButton"
        );

    const leftButton =
        element.querySelector(
            ".scrollLeft"
        );

    const rightButton =
        element.querySelector(
            ".scrollRight"
        );

    if (grid) {
        grid.classList.add(
            "expanded"
        );
    }

    if (expandButton) {
        expandButton.textContent =
            "Свернуть ↑";
    }

    if (leftButton) {
        leftButton.style.display =
            "none";
    }

    if (rightButton) {
        rightButton.style.display =
            "none";
    }
}

        /*
         * Ставим «Для тебя»
         * первой секцией.
         */

        const sections =
            $("sections");

        if (
            element &&
            sections.firstChild !==
                element
        ) {
            sections.prepend(
                element
            );
        }

    } catch (error) {

        if (
            error?.name ===
            "AbortError"
        ) {
            return;
        }

        console.error(
            "Personal recommendations:",
            error
        );
    }
}

	/* =========================
	   DISCOVER
	========================= */

	async function discover() {
		if (!token) {
			status(
				"Добавь TMDB Read Access Token в настройках."
			);

			return;
		}

		if (controller) {
			controller.abort();
		}

		controller =
			new AbortController();

		const signal =
			controller.signal;

		$("sections").innerHTML = "";

		status(
			"Загружаем фильмы…"
		);

		try {
			const selectedGenre =
				$("genre").value;

			if (selectedGenre) {
				const params =
					await buildDiscoverParams();

				let nextPage = 4;

				const movies =
					await fetchDiscoverPages(
						params,
						3,
						signal
					);

				const filtered =
					filterExcludedMovies(
						movies
					);

				if (!filtered.length) {
					status(
						"По этим фильтрам ничего не найдено."
					);

					return;
				}

				section(
					selectedGenre === "adult"
						? "🔞 18+"
						: "Подборка",
					filtered,
					"",
					async () => {

						const newMovies =
							await fetchDiscoverPages(
								params,
								3,
								signal,
								nextPage
							);

						nextPage += 3;

						return filterExcludedMovies(
							newMovies
						);
					}
				);

				status(
					`Найдено: ${filtered.length}`
				);

				return;
			}


			const base =
				filterParams();

			const popularParams = {
				...base,

				sort_by:
					"popularity.desc"
			};

			const ratingParams = {
				...base,

				sort_by:
					"vote_average.desc",

				"vote_count.gte":
					"300"
			};

			const newParams = {
				...base,

				sort_by:
					"primary_release_date.desc"
			};


			const [
				popular,
				topRated,
				newest
			] = await Promise.all([
				fetchDiscoverPages(
					popularParams,
					3,
					signal
				),

				fetchDiscoverPages(
					ratingParams,
					3,
					signal
				),

				fetchDiscoverPages(
					newParams,
					3,
					signal
				)
			]);


			/*
			 * Каждая секция имеет
			 * собственную пагинацию.
			 */

			let popularNextPage = 4;
			let ratingNextPage = 4;
			let newestNextPage = 4;


			const sections = [
				[
					"🔥 Популярное",
					popular,
					popularParams,
					() => {

						const page =
							popularNextPage;

						popularNextPage += 3;

						return page;
					}
				],

				[
					"⭐ Высокий рейтинг",
					topRated,
					ratingParams,
					() => {

						const page =
							ratingNextPage;

						ratingNextPage += 3;

						return page;
					}
				],

				[
					"🆕 Новинки",
					newest,
					newParams,
					() => {

						const page =
							newestNextPage;

						newestNextPage += 3;

						return page;
					}
				]
			];


			sections.forEach(
    ([title, movies, params, getNextPage]) => {

        const filteredMovies =
            filterExcludedMovies(
                movies
            );

        if (!filteredMovies.length) {
            return;
        }

        section(
            title,
            filteredMovies,
            "",
            async () => {

                const startPage =
                    getNextPage();

                const newMovies =
                    await fetchDiscoverPages(
                        params,
                        3,
                        signal,
                        startPage
                    );

                return filterExcludedMovies(
                    newMovies
                );
            }
        );
    }
);


			status(
				"Готово"
			);

			loadPersonalRecommendations();

		} catch (error) {

			if (
				error?.name ===
				"AbortError"
			) {
				return;
			}

			console.error(
				"Discover error:",
				error
			);

			status(
				error.message ||
				"Ошибка загрузки фильмов."
			);
		}
	}


/* =========================
   SEARCH
========================= */

async function search() {

    if (!token) {
        status("Добавь TMDB Read Access Token в настройках.");
        return;
    }

    const rawQuery = $("query").value.trim();

    if (!rawQuery) {
        await discover();
        return;
    }

    if (controller) {
        controller.abort();
    }

    controller = new AbortController();

    const signal = controller.signal;

    $("sections").innerHTML = "";

    status("Ищем фильмы…");

    try {

        const genre = $("genre").value;
        const includeAdult = genre === "adult";


        /* =========================
           QUERY
        ========================= */

        const yearMatch = rawQuery.match(
            /(?:^|\s)(19\d{2}|20\d{2})(?:\s|$)/
        );

        const requestedYear =
            yearMatch
                ? Number(yearMatch[1])
                : null;

        const searchQuery =
            rawQuery
                .replace(
                    /(?:^|\s)(19\d{2}|20\d{2})(?=\s|$)/g,
                    " "
                )
                .replace(/\s+/g, " ")
                .trim() || rawQuery;


        /* =========================
           TRANSLITERATION
        ========================= */

        function transliterate(value) {

            const map = {
                а:"a", б:"b", в:"v", г:"g", д:"d",
                е:"e", ё:"e", ж:"zh", з:"z", и:"i",
                й:"y", к:"k", л:"l", м:"m", н:"n",
                о:"o", п:"p", р:"r", с:"s", т:"t",
                у:"u", ф:"f", х:"h", ц:"c", ч:"ch",
                ш:"sh", щ:"sch", ъ:"", ы:"y", ь:"",
                э:"e", ю:"yu", я:"ya"
            };

            return String(value || "")
                .toLowerCase()
                .split("")
                .map(char => map[char] ?? char)
                .join("");
        }


        function transliterateBack(value) {

            const map = {
                sch:"щ",
                sh:"ш",
                ch:"ч",
                zh:"ж",
                yu:"ю",
                ya:"я",

                a:"а", b:"б", v:"в", g:"г",
                d:"д", e:"е", z:"з", i:"и",
                y:"й", k:"к", l:"л", m:"м",
                n:"н", o:"о", p:"п", r:"р",
                s:"с", t:"т", u:"у", f:"ф",
                h:"х", c:"ц"
            };

            let result =
                String(value || "")
                    .toLowerCase();

            for (const [from, to] of Object.entries(map)) {
                result = result.replaceAll(from, to);
            }

            return result;
        }


        const normalizedQuery =
            normalizeSearchText(searchQuery);

        const transliteratedQuery =
            normalizeSearchText(
                transliterate(searchQuery)
            );

        const backTransliteratedQuery =
            normalizeSearchText(
                transliterateBack(searchQuery)
            );


        /* =========================
           SEARCH VARIANTS
        ========================= */

        const queryVariants =
            [...new Set([
                searchQuery,
                transliterate(searchQuery),
                transliterateBack(searchQuery)
            ].filter(Boolean))];


        /* =========================
           TMDB SEARCH
        ========================= */

        async function requestSearch(
            language,
            query,
            startPage = 1,
            pages = 3
        ) {

            const requests = [];

            for (
                let page = startPage;
                page < startPage + pages;
                page++
            ) {

                requests.push(
                    api(
                        "/search/movie",
                        {
                            query,
                            language,

                            include_adult:
                                includeAdult
                                    ? "true"
                                    : "false",

                            ...(requestedYear
                                ? {
                                    year:
                                        requestedYear
                                }
                                : {}),

                            page
                        },
                        signal
                    )
                );
            }

            const responses =
                await Promise.all(requests);

            return responses.flatMap(
                response =>
                    response.results || []
            );
        }


        const requests = [];

        for (const query of queryVariants) {

            requests.push(
                requestSearch(
                    "ru-RU",
                    query,
                    1,
                    3
                )
            );

            requests.push(
                requestSearch(
                    "en-US",
                    query,
                    1,
                    3
                )
            );
        }


        const results =
            await Promise.all(requests);


        const allMovies =
            dedupeMovies(
                results.flat()
            );


        /* =========================
           NORMALIZE TITLE
        ========================= */

        function cleanTitle(value) {

            return normalizeSearchText(
                String(value || "")
                    .replace(
                        /[^\p{L}\p{N}\s]/gu,
                        " "
                    )
                    .replace(/\s+/g, " ")
                    .trim()
            );
        }


        function removeArticles(value) {

            return cleanTitle(value)
                .replace(
                    /^(the|a|an|и|а)\s+/,
                    ""
                )
                .trim();
        }


        /* =========================
           TITLE MATCH
        ========================= */

        function titleScore(
            title,
            query
        ) {

            title = cleanTitle(title);
            query = cleanTitle(query);

            if (!title || !query) {
                return 0;
            }


            if (title === query) {
                return 100000;
            }


            if (
                removeArticles(title) ===
                removeArticles(query)
            ) {
                return 90000;
            }


            if (title.startsWith(query)) {
                return 60000;
            }


            if (
                removeArticles(title)
                    .startsWith(
                        removeArticles(query)
                    )
            ) {
                return 55000;
            }


            if (title.includes(query)) {
                return 40000;
            }


            const queryWords =
                query
                    .split(" ")
                    .filter(Boolean);

            const titleWords =
                title
                    .split(" ")
                    .filter(Boolean);


            let matched = 0;
            let score = 0;


            for (const word of queryWords) {

                if (
                    titleWords.includes(word)
                ) {
                    matched++;
                    score += 9000;
                    continue;
                }


                if (
                    title.includes(word)
                ) {
                    matched++;
                    score += 4500;
                    continue;
                }


                /*
                 * Небольшая защита от опечаток.
                 *
                 * Короткие слова специально
                 * НЕ сравниваем fuzzy-поиском.
                 */

                if (word.length >= 4) {

                    let best = 0;

                    for (
                        const titleWord
                        of titleWords
                    ) {

                        if (
                            titleWord.length < 4
                        ) {
                            continue;
                        }

                        const distance =
                            levenshtein(
                                word,
                                titleWord
                            );

                        const maxLength =
                            Math.max(
                                word.length,
                                titleWord.length
                            );

                        const similarity =
                            1 -
                            distance /
                            maxLength;

                        best =
                            Math.max(
                                best,
                                similarity
                            );
                    }


                    if (best >= 0.72) {
                        matched++;
                        score +=
                            Math.round(
                                best * 6500
                            );
                    }
                }
            }


            if (
                queryWords.length &&
                matched === queryWords.length
            ) {
                score += 18000;
            }
            else if (
                matched > 0
            ) {
                score +=
                    matched /
                    queryWords.length *
                    5000;
            }


            return score;
        }


        /* =========================
           RANKING
        ========================= */

        function getSearchScore(movie) {

            const titles = [
                movie.title,
                movie.original_title
            ];


            const scores = [];


            /*
             * Обычный поиск.
             */

            for (const title of titles) {

                scores.push(
                    titleScore(
                        title,
                        normalizedQuery
                    )
                );

                scores.push(
                    titleScore(
                        title,
                        transliteratedQuery
                    )
                );

                scores.push(
                    titleScore(
                        title,
                        backTransliteratedQuery
                    )
                );
            }


            const bestTitleScore =
                Math.max(
                    0,
                    ...scores
                );


            let score =
                bestTitleScore;


            /* =========================
               YEAR
            ========================= */

            if (
                requestedYear &&
                movie.release_date
            ) {

                const releaseYear =
                    Number(
                        String(
                            movie.release_date
                        ).slice(0, 4)
                    );


                if (
                    releaseYear ===
                    requestedYear
                ) {

                    score += 30000;

                }
                else {

                    const difference =
                        Math.abs(
                            releaseYear -
                            requestedYear
                        );

                    score -=
                        Math.min(
                            20000,
                            difference * 1500
                        );
                }
            }


            /* =========================
               POPULARITY
            ========================= */

            score +=
                Math.log10(
                    Math.max(
                        1,
                        Number(
                            movie.popularity || 0
                        )
                    )
                ) * 25;


            /* =========================
               RATING
            ========================= */

            score +=
                Number(
                    movie.vote_average || 0
                ) * 8;


            /*
             * Популярность не должна
             * перебивать совпадение названия.
             */

            return score;
        }


        function rankMovies(movies) {

            return movies
                .map(movie => ({

                    movie,

                    score:
                        getSearchScore(
                            movie
                        )

                }))
                .filter(
                    item =>
                        item.score >= 2500
                )
                .sort(
                    (a, b) =>
                        b.score -
                        a.score
                )
                .map(
                    item =>
                        item.movie
                );
        }


        let rankedMovies =
            rankMovies(
                allMovies
            );


        /* =========================
           EXCLUSIONS
        ========================= */

        rankedMovies =
            filterExcludedMovies(
                rankedMovies
            );


        /* =========================
           ADULT
        ========================= */

        async function filterAdultMovies(
            movies
        ) {

            if (
                !includeAdult ||
                !movies.length
            ) {
                return movies;
            }


            const keywordIds =
                await getAdultKeywordIds();


            if (
                !keywordIds.length
            ) {
                return movies;
            }


            const candidates =
                movies.slice(
                    0,
                    80
                );


            const checks =
                await Promise.all(
                    candidates.map(
                        async movie => {

                            try {

                                const data =
                                    await api(
                                        `/movie/${movie.id}/keywords`,
                                        {},
                                        signal
                                    );


                                const ids =
                                    (
                                        data.keywords ||
                                        []
                                    ).map(
                                        keyword =>
                                            Number(
                                                keyword.id
                                            )
                                    );


                                return keywordIds.some(
                                    id =>
                                        ids.includes(
                                            Number(id)
                                        )
                                )
                                    ? movie
                                    : null;

                            }
                            catch {

                                return null;
                            }
                        }
                    )
                );


            return checks.filter(
                Boolean
            );
        }


        rankedMovies =
            await filterAdultMovies(
                rankedMovies
            );


        /* =========================
           NOTHING FOUND
        ========================= */

        if (
            !rankedMovies.length
        ) {

            status(
                "Ничего подходящего не найдено."
            );

            return;
        }


        /* =========================
           FIRST RESULTS
        ========================= */

        const movies =
            rankedMovies.slice(
                0,
                30
            );


        const displayedIds =
            new Set(
                movies.map(
                    movie =>
                        String(
                            movie.id
                        )
                )
            );


        /* =========================
           PAGINATION
        ========================= */

        let nextPage = 4;


        async function loadMoreSearch() {

            const requests = [];


            for (const query of queryVariants) {

                requests.push(
                    requestSearch(
                        "ru-RU",
                        query,
                        nextPage,
                        3
                    )
                );

                requests.push(
                    requestSearch(
                        "en-US",
                        query,
                        nextPage,
                        3
                    )
                );
            }


            const results =
                await Promise.all(
                    requests
                );


            nextPage += 3;


            let newMovies =
                dedupeMovies(
                    results.flat()
                );


            newMovies =
                rankMovies(
                    newMovies
                );


            newMovies =
                filterExcludedMovies(
                    newMovies
                );


            newMovies =
                newMovies.filter(
                    movie => {

                        const id =
                            String(
                                movie.id
                            );


                        if (
                            displayedIds.has(id)
                        ) {
                            return false;
                        }


                        displayedIds.add(id);

                        return true;
                    }
                );


            newMovies =
                await filterAdultMovies(
                    newMovies
                );


            return newMovies;
        }


        /* =========================
           DISPLAY
        ========================= */

        section(

            includeAdult
                ? "🔞 18+ — поиск"
                : `🔎 Результаты: ${rawQuery}`,

            movies,

            "",

            loadMoreSearch

        );


        /* =========================
           STATUS
        ========================= */

        status(
            requestedYear
                ? `Найдено: ${movies.length} · год: ${requestedYear}`
                : `Найдено: ${movies.length}`
        );


    }
    catch (error) {

        if (
            error?.name ===
            "AbortError"
        ) {
            return;
        }


        console.error(
            "Search error:",
            error
        );


        status(
            error.message ||
            "Ошибка поиска."
        );
    }
}

	/* =========================
	   RANDOM MOVIE
	========================= */

	async function randomMovie() {
		if (!token) {
			status(
				"Добавь TMDB Read Access Token в настройках."
			);

			return;
		}

		if (controller) {
			controller.abort();
		}

		controller =
			new AbortController();

		const signal =
			controller.signal;

		status(
			"Ищем случайный фильм…"
		);

		try {

			const params =
				await buildDiscoverParams();

			const movies =
				await fetchDiscoverPages(
					params,
					3,
					signal
				);

			const available =
				filterExcludedMovies(
					movies
				);

			if (!available.length) {
				status(
					"Не удалось найти подходящий фильм."
				);

				return;
			}

			const shuffled =
				randomizeMovies(
					available
				);

			const movie =
				shuffled[0];

			$("sections").innerHTML = "";

			section(
				"🎲 Случайный фильм",
				[movie]
			);

			status(
				"Вот что выпало 🎬"
			);

		} catch (error) {

			if (
				error?.name ===
				"AbortError"
			) {
				return;
			}

			console.error(
				"Random error:",
				error
			);

			status(
				error.message ||
				"Ошибка."
			);
		}
	}


	/* =========================
	   SETTINGS
	========================= */

	function openSettings() {
		$("settings").classList.remove(
			"hidden"
		);

		$("token").value =
			token || "";
	}

	function closeSettings() {
		$("settings").classList.add(
			"hidden"
		);
	}

	async function saveToken() {
		const value =
			$("token").value.trim();

		if (!value) {
			status(
				"Введи TMDB Read Access Token."
			);

			return;
		}

		token = value;

		await new Promise(resolve => {
			chrome.storage.local.set(
				{
					tmdb_token: token
				},
				resolve
			);
		});

		cache.clear();

		adultKeywordIds = [];

		closeSettings();

		status(
			"Токен сохранён."
		);

		await discover();
	}

	async function clearToken() {
		token = "";

		cache.clear();

		adultKeywordIds = [];

		await new Promise(resolve => {
			chrome.storage.local.remove(
				"tmdb_token",
				resolve
			);
		});

		$("token").value = "";

		status(
			"Токен удалён."
		);
	}


	/* =========================
	   LOAD TOKEN
	========================= */

	async function loadToken() {
		return new Promise(resolve => {
			chrome.storage.local.get(
				["tmdb_token"],
				data => {

					token =
						data.tmdb_token ||
						"";

					resolve();
				}
			);
		});
	}


	/* =========================
	   FAVORITES MODAL
	========================= */

	function openFavorites() {
		renderFavorites();

		$("favorites").classList.remove(
			"hidden"
		);
	}

	function closeFavorites() {
		$("favorites").classList.add(
			"hidden"
		);
	}

	async function clearLikeHistory() {
		const confirmed =
			confirm(
				"⚠️ Сбросить рекомендации?\n\n" +
				"Будет удалена история лайков и дизлайков.\n" +
				"Персональные рекомендации будут сброшены.\n\n" +
				"Избранные фильмы не будут удалены.\n\n" +
				"Это действие нельзя отменить."
			);

		if (!confirmed) {
			return;
		}

		likedMovies = {};
		dislikedMovies = {};

		saveLikes();
		saveDislikes();

		recommendationGeneration++;

		const personalSection =
			document.getElementById(
				"personalRecommendations"
			);

		if (personalSection) {
			personalSection.remove();
		}

		closeFavorites();

await discover();

status(
    "Рекомендации сброшены."
);
	}


	/* =========================
	   MODAL OUTSIDE CLICK
	========================= */

	function setupModalEvents() {
		const settings =
			$("settings");

		const favorites =
			$("favorites");

		settings.addEventListener(
			"click",
			event => {

				if (
					event.target ===
					settings
				) {
					closeSettings();
				}
			}
		);

		favorites.addEventListener(
			"click",
			event => {

				if (
					event.target ===
					favorites
				) {
					closeFavorites();
				}
			}
		);
	}


	/* =========================
	   FILTER EVENTS
	========================= */

	function setupFilterEvents() {
		const filterIds = [
			"genre",
			"rating",
			"age",
			"year",
			"sort"
		];

		filterIds.forEach(id => {

			const element =
				$(id);

			if (!element) {
				return;
			}

			element.addEventListener(
				"change",
				() => {
					discover();
				}
			);
		});
	}


	/* =========================
	   SEARCH EVENTS
	========================= */

	function setupSearchEvents() {
		$("searchBtn").addEventListener(
			"click",
			() => {
				search();
			}
		);

		$("query").addEventListener(
			"keydown",
			event => {

				if (
					event.key ===
					"Enter"
				) {
					event.preventDefault();

					search();
				}
			}
		);
	}


	/* =========================
	   BUTTON EVENTS
	========================= */

	function setupButtons() {
    $("navHome").addEventListener(
        "click",
        () => {
            window.location.href =
                chrome.runtime.getURL("newtab.html");
        }
    );

    const navMovies = $("navMovies");

    if (navMovies) {
        navMovies.classList.add("active");
    }

    const navSeries = $("navSeries");

    if (navSeries) {
        navSeries.addEventListener(
            "click",
            () => {
                window.location.href =
                    chrome.runtime.getURL("series.html");
            }
        );
    }

		$("randomBtn").addEventListener(
			"click",
			() => {
				randomMovie();
			}
		);

		$("settingsBtn").addEventListener(
			"click",
			() => {
				openSettings();
			}
		);

		$("closeSettings").addEventListener(
			"click",
			() => {
				closeSettings();
			}
		);

		$("saveToken").addEventListener(
			"click",
			() => {
				saveToken();
			}
		);

		$("clearToken").addEventListener(
			"click",
			() => {
				clearToken();
			}
		);

		$("favoritesBtn").addEventListener(
			"click",
			() => {
				openFavorites();
			}
		);

		$("clearLikesBtn").addEventListener(
			"click",
			() => {
				clearLikeHistory();
			}
		);
	}


	/* =========================
	   KEYBOARD
	========================= */

	function setupKeyboard() {

		document.addEventListener(
			"keydown",
			event => {

				if (
					event.key ===
					"Escape"
				) {
					closeSettings();
					closeFavorites();
					closeTrailer();

					return;
				}

				if (
					event.key === "/" &&
					document.activeElement.tagName !==
						"INPUT"
				) {
					event.preventDefault();

					$("query").focus();
				}
			}
		);
	}


	/* =========================
	   INITIALIZE
	========================= */

	async function init() {

		installEnhancementStyles();

		ensureAdultGenreOption();

		years();

		await loadStorage();

		await loadToken();

		updateFavoritesButton();

		setupModalEvents();
		setupFilterEvents();
		setupSearchEvents();
		setupButtons();
		setupKeyboard();

		renderFavorites();

		if (!token) {
			status(
				"Открой ⚙ и добавь TMDB Read Access Token."
			);

			return;
		}

		await discover();
	}


	/* =========================
	   START
	========================= */

	document.addEventListener(
		"DOMContentLoaded",
		() => {

			init().catch(error => {

				console.error(
					"Initialization error:",
					error
				);

				status(
					error.message ||
					"Не удалось запустить Movie Picker."
				);
			});
		}
	);


	document.addEventListener("click", event => {

		const closeButton =
			event.target.closest(
				"#closeFavorites"
			);

		if (!closeButton) {
			return;
		}

		event.preventDefault();
		event.stopPropagation();

		const favorites =
			document.getElementById(
				"favorites"
			);

		if (favorites) {
			favorites.classList.add(
				"hidden"
			);
		}
	});


	document.addEventListener("click", event => {

		const favorites =
			document.getElementById(
				"favorites"
			);

		if (
			favorites &&
			event.target === favorites
		) {
			favorites.classList.add(
				"hidden"
			);
		}
	});


	/* =========================
	   SCROLL TO TOP
	========================= */

	const scrollTopButton =
		document.createElement("button");

	scrollTopButton.id =
		"scrollTopButton";

	scrollTopButton.textContent =
		"↑";

	scrollTopButton.title =
		"Наверх";

	document.body.appendChild(
		scrollTopButton
	);

	window.addEventListener(
		"scroll",
		() => {

			if (window.scrollY > 500) {

				scrollTopButton.classList.add(
					"visible"
				);

			} else {

				scrollTopButton.classList.remove(
					"visible"
				);
			}
		}
	);

	scrollTopButton.addEventListener(
		"click",
		() => {

			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
	);

	/* =========================
	   AUTHOR / SUPPORT
	========================= */

	const supportButton =
		document.getElementById(
			"supportButton"
		);

	if (supportButton) {

		supportButton.addEventListener(
			"click",
			() => {

				window.open(
					"https://boosty.to/miha1ych/single-payment/donation/827035/target?share=target_link",
					"_blank"
				);
			}
		);
	}
	
	function createLikeBurst(button) {
    const rect = button.getBoundingClientRect();

    const burst = document.createElement("div");
    burst.className = "likeBurst";

    burst.style.left =
        `${rect.left + rect.width / 2}px`;

    burst.style.top =
        `${rect.top + rect.height / 2}px`;

    const count = 7;

    for (let i = 0; i < count; i++) {
        const heart = document.createElement("span");

        heart.className = "burstHeart";
        heart.textContent = "♥";

        const angle =
            (-Math.PI / 2) +
            ((Math.random() - .5) * 1.1);

        const distance =
            24 + Math.random() * 34;

        const x =
            Math.cos(angle) * distance;

        const y =
            Math.sin(angle) * distance;

        heart.style.setProperty("--x", `${x}px`);
        heart.style.setProperty("--y", `${y}px`);

        heart.style.setProperty(
            "--delay",
            `${Math.random() * .12}s`
        );

        heart.style.setProperty(
            "--size",
            `${7 + Math.random() * 6}px`
        );

        burst.appendChild(heart);
    }

    document.body.appendChild(burst);

    setTimeout(() => {
        burst.remove();
    }, 900);
}
function createFavoriteBurst(button) {
    const rect = button.getBoundingClientRect();

    const burst = document.createElement("div");
    burst.className = "favoriteBurst";

    burst.style.left =
        `${rect.left + rect.width / 2}px`;

    burst.style.top =
        `${rect.top + rect.height / 2}px`;

    const count = 7;

    for (let i = 0; i < count; i++) {
        const star = document.createElement("span");

        star.className = "burstStar";
        star.textContent = "★";

        const angle =
            (-Math.PI / 2) +
            ((Math.random() - .5) * 1.1);

        const distance =
            24 + Math.random() * 34;

        const x =
            Math.cos(angle) * distance;

        const y =
            Math.sin(angle) * distance;

        star.style.setProperty("--x", `${x}px`);
        star.style.setProperty("--y", `${y}px`);

        star.style.setProperty(
            "--delay",
            `${Math.random() * .12}s`
        );

        star.style.setProperty(
            "--size",
            `${7 + Math.random() * 6}px`
        );

        burst.appendChild(star);
    }

    document.body.appendChild(burst);

    setTimeout(() => {
        burst.remove();
    }, 900);
}