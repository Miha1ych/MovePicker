const YOUTUBE_RULE_ID = 1;

async function setupYouTubeRule() {
    const rule = {
        id: YOUTUBE_RULE_ID,
        priority: 1,

        action: {
            type: "modifyHeaders",
            requestHeaders: [
                {
                    header: "Referer",
                    operation: "set",
                    value: "https://example.com/"
                }
            ]
        },

        condition: {
            initiatorDomains: [chrome.runtime.id],
            requestDomains: [
                "youtube.com",
                "youtube-nocookie.com"
            ],
            resourceTypes: [
                "sub_frame"
            ],
            urlFilter: "/embed/"
        }
    };

    await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [YOUTUBE_RULE_ID],
        addRules: [rule]
    });
}

chrome.runtime.onInstalled.addListener(() => {
    setupYouTubeRule().catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
    setupYouTubeRule().catch(console.error);
});


chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({
        url: chrome.runtime.getURL("newtab.html"),
        active: true
    });
});


chrome.commands.onCommand.addListener(command => {
    if (command === "open-movie-picker") {
        chrome.tabs.create({
            url: chrome.runtime.getURL("newtab.html"),
            active: true
        });
    }
});